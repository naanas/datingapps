package com.dating.apps.datingapps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatingappsApplicationTests {

	@Test
	void contextLoads() {
	}

}
